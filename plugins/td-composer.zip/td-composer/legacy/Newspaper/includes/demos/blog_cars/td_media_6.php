<?php
td_demo_media::add_image_to_media_gallery('td_blog_cars_post_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/banner-post.jpg");
td_demo_media::add_image_to_media_gallery('td_blog_cars_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/banner-sidebar.jpg");
// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/blog_cars/logo-header.png");