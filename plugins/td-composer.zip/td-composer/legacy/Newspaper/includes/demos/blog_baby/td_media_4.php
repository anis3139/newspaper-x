<?php
td_demo_media::add_image_to_media_gallery('td_pic_10',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_baby/10.jpg");
// post photos
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_baby/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_baby/p2.jpg");

