<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/author-hero.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/logo-image.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/author.png');
