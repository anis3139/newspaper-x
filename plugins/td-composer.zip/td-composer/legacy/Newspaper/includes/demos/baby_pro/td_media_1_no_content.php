<?php
// featured images
td_demo_media::add_image_to_media_gallery('td_pic_1',       'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/1.jpg');
// ads
td_demo_media::add_image_to_media_gallery('tdx_pic_4',      'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/reclama-sidebar.png');
//logo
td_demo_media::add_image_to_media_gallery('tdx_pic_7',      'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/logo-image.png');