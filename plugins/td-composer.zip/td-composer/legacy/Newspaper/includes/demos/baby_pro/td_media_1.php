<?php
td_demo_media::add_image_to_media_gallery('td_pic_1', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/1.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/2.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/3.jpg');
