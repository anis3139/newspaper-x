<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_15', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/member5.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/p3.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/tdn_pic_3.png');
