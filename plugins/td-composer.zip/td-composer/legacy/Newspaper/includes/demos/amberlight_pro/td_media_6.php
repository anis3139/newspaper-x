<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/reclama-square3.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/404-bg.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/search-img2.jpg');


