<?php
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/52.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/51.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/50.jpg');

