<?php
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/black_pro/media/4.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/black_pro/media/5.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/black_pro/media/6.jpg');
