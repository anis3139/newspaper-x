<?php
// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/architecture_logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/architecture_logo_retina.png");
td_demo_media::add_image_to_media_gallery('td_logo_footer',             "http://demo_content.tagdiv.com/Newspaper_6/blog_architecture/architecture_logo_footer.png");