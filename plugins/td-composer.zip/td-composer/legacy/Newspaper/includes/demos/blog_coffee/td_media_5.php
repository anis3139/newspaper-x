<?php
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_coffee/p3.jpg");
// ads
td_demo_media::add_image_to_media_gallery('td_blog_coffee_ad',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_coffee/rec.jpg");
// other images
td_demo_media::add_image_to_media_gallery('aboutme',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_coffee/aboutme.jpg");
