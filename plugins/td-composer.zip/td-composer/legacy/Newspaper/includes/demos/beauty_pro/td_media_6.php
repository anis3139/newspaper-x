<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/tag-img.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/date-img.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/reclama2.jpg');
