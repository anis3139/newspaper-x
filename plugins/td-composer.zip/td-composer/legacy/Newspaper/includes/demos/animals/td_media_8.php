<?php
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             'http://demo_content.tagdiv.com/Newspaper_6/animals/logo-mobile.png');
td_demo_media::add_image_to_media_gallery('td_animals_bg',              'http://demo_content.tagdiv.com/Newspaper_6/animals/bg.jpg');
td_demo_media::add_image_to_media_gallery('td_animals_header_ad',               "http://demo_content.tagdiv.com/Newspaper_6/animals/banner-header.png");
